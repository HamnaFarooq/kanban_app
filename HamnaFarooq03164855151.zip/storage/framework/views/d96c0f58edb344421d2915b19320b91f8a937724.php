<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- ======= Header ======= -->
    <!-- <header id="header">
        <div class="d-flex flex-column">

            <div class="profile pt-4">
                <h1 class="text-light"></h1>
            </div>

            <nav id="navbar" class="nav-menu navbar pt-5">
                <ul>
                    <li><a href="/admin_dashboard" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
                    <li><a href="" class="nav-link scrollto"><i class="bx bx-user"></i> <span> Lists </span></a></li>
                    <li><a href="" class="nav-link scrollto"><i class="bx bx-user"></i> <span> Users </span></a></li>
                </ul>
            </nav>
        </div>
    </header> -->
    <!-- End Header -->

    <!-- <main id="main"> -->

    <h2 class="mb-2"> Lists </h2>

    <div class="row py-3" style="display: block;">
        <form action="/add_list" method="POST" autocomplete="off" class="d-flex">
            <?php echo csrf_field(); ?>

            <div class="flex-fill">
                <input type="text" class="form-control" name="title" placeholder="Enter title" required>
            </div>
            <div>
                <button type="submit" class="btn btn-primary">Add List</button>
            </div>
        </form>
        <!-- <button class="btn btn-primary ml-auto" data-toggle="modal" data-target="#addArea">Add another Area</button> -->
    </div>


    <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('includes.add_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.edit_list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php if( ($loop->index+1) % 3 == 1 ): ?>
    <div class="row">
        <?php endif; ?>

        <div class="col-xs-12 col-md-4 p-1">
            <div class="p-0 card border-primary mb-3">
                <div class="card-header d-flex justify-content-between"> <b class="mt-2"> <?php echo e($list->title); ?> </b>
                    <div> <button class="btn btn-secondary" data-toggle="modal" data-target="#edit_list_<?php echo e($list->id); ?>"> <i class="fa fa-pencil"></i> </button> <button class="btn btn-primary" data-toggle="modal" data-target="#add_card_<?php echo e($list->id); ?>">+</button> </div>
                </div>
                <div class="card-body">

                    <div class="mb-3">
                        <?php $total = $list->cards->count(); $complete = $list->cards->where('completed', '1')->count();
                        if($total > 0)
                        $progress = ($complete/$total)*100;
                        else
                        $progress = 0;
                        ?>
                        <label> Progress: </label>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($progress); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <div class="accordion" id="accordionExample">
                        <?php $__currentLoopData = $list->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make('includes.edit_card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php echo $__env->make('includes.add_card_attachment', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>">
                                    <?php if($card->completed == 0): ?> <input type="checkbox" onclick="window.location.assign('/complete_card/<?php echo e($card->id); ?>');" class="me-2"> <?php else: ?> <input type="checkbox" checked onclick="window.location.assign('/incomplete_card/<?php echo e($card->id); ?>');" class="me-2"> <?php endif; ?> <?php echo e($card->title); ?>

                                </button>
                            </h2>
                            <div id="collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <div class="d-flex justify-content-end"> <button class="btn btn-dark me-1" data-toggle="modal" data-target="#edit_card_<?php echo e($card->id); ?>"><i class="fa fa-pencil"></i></button> <a href="/delete_card/<?php echo e($card->id); ?>"> <button class="btn btn-danger"><i class="fa fa-trash"></i></button> </a> </div>
                                    <br>
                                    <strong>Description:</strong>
                                    <?php echo e($card->description); ?>


                                    <img src="<?php echo e($card->attachment); ?>" alt="" width="100%">

                                    <div class="d-flex justify-content-end mt-3"> <b class="me-2 mt-2"> Attachment: </b> <button class="btn btn-dark p-1 me-1" data-toggle="modal" data-target="#add_card_attachment<?php echo e($card->id); ?>"> + </button> <a href="<?php echo e($card->attachment); ?>" download="img.jpg"><button class="btn btn-dark p-1 me-1 "><i class="fa fa-download"></i></button> </a> <a href="/delete_card_attachment/<?php echo e($card->id); ?>"> <button class="btn btn-danger p-1"><i class="fa fa-trash"></i></button> </a> </div>

                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>

        <?php if( ($loop->index+1) % 3 == 0 ): ?>
    </div>
    <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <br>
    <hr>



    <!-- </main> -->


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/editor/dashboard.blade.php ENDPATH**/ ?>