<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Kanban App</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

    <!-- css -->
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?> ">

    <!-- Js -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">Kanban App</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarColor01">
                <ul class="navbar-nav ms-auto">
                    <?php if(auth()->guard()->check()): ?>
                    <li class="nav-item">
                        <a href="<?php echo e(url('/dashboard')); ?>" class="nav-link">Dashboard</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" data-bs-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false"><?php echo e(Auth::user()->name); ?></a>
                        <div class="dropdown-menu">
                            <form method="POST" action="<?php echo e(route('logout')); ?>">
                                <?php echo csrf_field(); ?>
                                <a class="dropdown-item" href="route('logout')" onclick="event.preventDefault();this.closest('form').submit();"><?php echo e(__('Log Out')); ?></a>
                            </form>
                        </div>
                    </li>
                    <?php else: ?>
                    <!-- <a href="/login" class="nav-link">Log in</a> -->
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>

    <div class="temorary_msg">

        <?php if(( Session::get('errors') ?? 0 )): ?>
        <!-- for error in a form -->
        <div class="alert alert-dismissible alert-danger text-center">
            <strong>Oh snap!</strong> There was a error! Please consider the following things and try submitting again.
            <p class="mb-0">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="text-danger">
                <?php echo e($error); ?>

            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </p>
        </div>
        <?php endif; ?>

        <?php if( session('success') ): ?>
        <div class="alert alert-dismissible alert-success text-center">
            <strong>Great!</strong> <?php echo e(session('success')); ?>

        </div>
        <?php endif; ?>

        <?php if( session('errormsg') ): ?>
        <!-- for personal error message -->
        <div class="alert alert-dismissible alert-danger text-center">
            <strong>Oh snap!</strong> <?php echo e(session('errormsg')); ?>

        </div>
        <?php endif; ?>
    </div>

    <main class="container py-5" style="min-height: 90vh;">
        <?php echo e($slot); ?>

    </main>

</body>

<script>
    $(function() {
        setTimeout(function() {
            $(".temorary_msg").fadeOut();
        }, 5000);
    });
</script>

</html><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/layouts/app.blade.php ENDPATH**/ ?>