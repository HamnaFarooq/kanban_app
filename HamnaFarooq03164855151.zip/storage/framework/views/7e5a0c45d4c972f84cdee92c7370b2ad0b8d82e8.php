<div class="modal fade" id="add_card_attachment<?php echo e($card->id); ?>" tabindex="-1" role="dialog" aria-labelledby="add_card_attachment<?php echo e($card->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">

        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="exampleModalLongTitle">Add Card Attachment</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <!-- form -->
                <form action="/add_card_attachment/<?php echo e($card->id); ?>" method="POST" autocomplete="off" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="formFile" class="form-label mt-4">Add File</label>
                        <input class="form-control" type="file" id="formFile" name="attachment" accept="image/*">
                    </div>

                    <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-danger">
                        <?php echo e($error); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary ms-auto mt-3">Add</button>

                </form>

            </div>

        </div>

    </div>
</div><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/includes/add_card_attachment.blade.php ENDPATH**/ ?>