<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- <h4 class="mt-5 mx-auto"> Heads up: </h4>
    <p>
        This app was made in the last 6.5 hours due to inavailablity of the laptop.
        Even though I am submitting this incomplete website. I will continue and submit the complete website in a day as well.
    </p> -->

    <?php if(auth()->guard()->check()): ?>
    <h4 class="mt-5 mx-auto"> You are Already Logged in, Goto <a href="<?php echo e(url('/dashboard')); ?>">Dashboard</a> </h4>
    <?php else: ?>

    <?php if($new_app): ?>

    <!-- Admin -->
    <div class="card border-primary mb-3 mx-auto col-xs-12 col-md-8">
        <div class="card-header bg-primary text-white text-center"> Welcome to your New App Admin! </div>
        <div class="card-body">
            <p class="card-text">Set Up Admin login credentials for this website.</p>

            <form method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Username -->
                <div class="control-group my-2">
                    <label class="control-label" for="name">Username</label>
                    <div class="controls">
                        <input id="name" class="block mt-1 w-full" type="text" name="name" :value="old('name')" required autofocus>
                    </div>
                </div>

                <!-- Email Address -->
                <div class="control-group my-2">
                    <label class="control-label" for="email">Email</label>
                    <div class="controls">
                        <input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required>
                    </div>
                </div>

                <!-- Password -->
                <div class="control-group my-2">
                    <label class="control-label" for="password"> Password </label>
                    <div class="controls">
                        <input id="password" class="block mt-1 w-full" type="password" name="password" required>
                    </div>
                </div>

                <!-- Confirm Password -->
                <div class="control-group my-2">
                    <label class="control-label" for="password_confirmation">Confirm Password </label>
                    <div class="controls">
                        <input id="password_confirmation" class="block mt-1 w-full" type="password" name="password_confirmation" required>
                    </div>
                </div>

                <div class="d-flex align-items-center justify-content-end mt-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-4 btn btn-primary']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4 btn btn-primary']); ?>
                        <?php echo e(__('Register')); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </form>

            <!-- Validation Errors -->
            <!-- <div style="color: red;">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div> -->

        </div>
    </div>

    <?php else: ?>

    <!-- User -->
    <div class="card border-primary mb-3 mx-auto col-xs-12 col-md-8">
        <div class="card-header bg-primary text-white text-center"> Welcome! </div>
        <div class="card-body">
            <p class="card-text">Please Log in first to see the dashboard.</p>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <!-- Email Address -->
                <div class="control-group my-2">
                    <label class="control-label" for="email">Email</label>
                    <div class="controls">
                        <input id="email" class="block mt-1 w-full" type="email" name="email" :value="old('email')" required autofocus>
                    </div>
                </div>

                <!-- Password -->
                <div class="control-group my-2">
                    <label class="control-label" for="password"> Password </label>
                    <div class="controls">
                        <input id="password" class="block mt-1 w-full" type="password" name="password" required>
                    </div>
                </div>

                <!-- Remember Me -->
                <div class="block mt-4">
                    <label for="remember_me" class="inline-flex items-center">
                        <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50" name="remember">
                        <span class="ml-2 text-sm text-gray-600"><?php echo e(__('Remember me')); ?></span>
                    </label>
                </div>

                <div class="d-flex align-items-center justify-content-end mt-4">
                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'ml-4 btn btn-primary']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'ml-4 btn btn-primary']); ?>
                        <?php echo e(__('Login')); ?>

                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                </div>
            </form>

            <!-- Validation Errors -->
            <!-- <div style="color: red;">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
            </div> -->

        </div>
    </div>

    <?php endif; ?>

    <?php endif; ?>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/welcome.blade.php ENDPATH**/ ?>