<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <!-- ======= Header ======= -->
    <header id="header">
        <div class="d-flex flex-column">

            <div class="profile pt-4">
                <h1 class="text-light"></h1>
            </div>

            <nav id="navbar" class="nav-menu navbar pt-5">
                <ul>
                    <li><a href="/admin_dashboard" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Home</span></a></li>
                    <li><a href="/admin_lists" class="nav-link scrollto"><i class="bx bx-user"></i> <span> Lists </span></a></li>
                    <li><a href="/admin_users" class="nav-link scrollto"><i class="bx bx-user"></i> <span> Users </span></a></li>
                </ul>
            </nav>
        </div>
    </header>
    <!-- End Header -->

    <main id="main">

        <h2 class="mb-2"> Lists </h2>

        <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php if( ($loop->index+1) % 3 == 1 ): ?>
        <div class="row">
            <?php endif; ?>

            <div class="col p-0 mx-1 card border-primary mb-3">
                <div class="card-header d-flex justify-content-between"> <b class="mt-2"> <?php echo e($list->title); ?> </b>
                </div>
                <div class="card-body">

                    <div class="mb-3">
                        <?php $total = $list->cards->count(); $complete = $list->cards->where('completed', '1')->count();
                        if($total > 0)
                        $progress = ($complete/$total)*100;
                        else
                        $progress = 0;
                        ?>
                        <label> Progress: </label>
                        <div class="progress">
                            <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo e($progress); ?>%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                        </div>
                    </div>
                    <div class="accordion" id="accordionExample">
                        <?php $__currentLoopData = $list->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="accordion-item">
                            <h2 class="accordion-header" id="headingOne">
                                <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>">
                                    <?php if($card->completed == 0): ?> <input type="checkbox" onclick="return false;" class="me-2"> <?php else: ?> <input type="checkbox" checked onclick="return false;" class="me-2"> <?php endif; ?> <?php echo e($card->title); ?>

                                </button>
                            </h2>
                            <div id="collapse<?php echo e($list->id); ?>_<?php echo e($card->id); ?>" class="accordion-collapse collapse" aria-labelledby="headingOne" data-bs-parent="#accordionExample">
                                <div class="accordion-body">
                                    <strong>Description:</strong>
                                    <?php echo e($card->description); ?>


                                    <img src="<?php echo e($card->attachment); ?>" alt="" width="100%">
                                </div>
                            </div>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <?php if( ($loop->index+1) % 3 == 0 ): ?>
        </div>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    </main>


 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>