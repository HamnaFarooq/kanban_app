<div class="modal fade" id="edit_list_<?php echo e($list->id); ?>" tabindex="-1" role="dialog" aria-labelledby="edit_list_<?php echo e($list->id); ?>" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">

        <div class="modal-content">
            <div class="modal-header">

                <h5 class="modal-title" id="exampleModalLongTitle">Edit</h5>

                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <!-- form -->
                <form action="/edit_list/<?php echo e($list->id); ?>" method="POST" autocomplete="off">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label>List Title:</label>
                        <input type="text" class="form-control" name="title" placeholder="Enter title" value="<?php echo e($list->title); ?>" required>
                    </div>

                    <?php if($errors->any()): ?>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="text-danger">
                        <?php echo e($error); ?>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                    <button type="submit" class="btn btn-primary ms-auto mt-3">Change</button>

                </form>

            </div>

        </div>

    </div>
</div><?php /**PATH C:\Users\HP\OneDrive\Desktop\kanban_app\resources\views/includes/edit_list.blade.php ENDPATH**/ ?>